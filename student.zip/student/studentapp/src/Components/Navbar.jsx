import React from 'react'
import App from '../App'
import { AppBar, Button , Toolbar } from '@mui/material'
import { Link } from 'react-router-dom'


const Navbar = () => {
  return (
    <div><AppBar>
<Toolbar>
<h3 color>
    studentapp
</h3>&nbsp;
<Link to ="/add">
<Button variant ='contained' color ='secondary'>add</Button></Link>&nbsp;&nbsp;
<Link to="/view">
<Button variant='contained' color='secondary'>view</Button>
</Link>&nbsp;&nbsp;
</Toolbar>


</AppBar>
    </div>
  )
}




export default Navbar