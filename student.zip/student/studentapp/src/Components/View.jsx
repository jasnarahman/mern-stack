import React, { useEffect, useState } from 'react'
import {  Button, ButtonBase, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material'

import { Navigate, useNavigate } from 'react-router-dom'
import axios from 'axios'

const View = () => {
  const navigate=useNavigate()

  var [user,setUser]=useState([])
  useEffect(()=>{
    axios.get("http://localhost:3009/view")
    .then((rs)=>
    {
      setUser(rs.data)
      console.log(user)
    })

  },[])
  
  const Handledelete=(id)=>{
    axios.delete('http://localhost:3009/delete'+id)
    .then((rs)=>{
      alert(rs.data)
    })
  }
  const HandleUpdate= (val)=>{
    console.log("data",val)
    navigate("/add",{state:{val}})
  }
  return (
    <div>

<br /><br />
<h3>STUDENT DETAILS</h3>
<TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>name</TableCell>
            <TableCell>age</TableCell>
            <TableCell>department</TableCell>
            <TableCell>mark</TableCell>

          </TableRow>
        </TableHead>
        <TableBody>
          {user.map((val)=>{
          return(

       
    
            <TableRow>
            <TableCell>{val.Name}</TableCell>
            <TableCell>{val.Age}</TableCell>
             <TableCell>{val.Department}</TableCell>
             <TableCell>{val.Mark}</TableCell>
             <Button variant='contained' onClick={()=>{Handledelete(val._id)}}>delete</Button>
             <Button variant="contained" onClick={()=>{HandleUpdate(val)}}>update</Button>
          </TableRow>
              )
        })}

        
          
        </TableBody>
      </Table>
    </TableContainer>





    </div>
  )
}

export default View