import { useEffect, useState } from 'react'
import { Button, TextField } from '@mui/material'
import { useLocation, useNavigate } from 'react-router-dom'
import axios from 'axios'
const Add = () => {
  const navigate = useNavigate()
  const location = useLocation()
  console.log(location.state)

  var [student, setStudent] = useState({Name:"",Age:"",Department:"",Mark:""})

  

  const submitHandler = () => {
    if (location.state!==null) {
      axios.put("http://localhost:3009/edit/" + location.state.val._id, student)
        .then((res) => {
          alert(res.data)
          navigate("/view")
        })
    } else {
      axios.post("http://localhost:3009/add", student)
        .then((res) => {
          alert(res.data)
          navigate("/")
        })
    }
  }

  const HandleInput = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value })
    console.log(student)
  }
if(location.state!=null){
  useEffect(()=>{
    setStudent({...student,
      Name:location.state.val.Name,
      Age:location.state.val.Age,
      Department:location.state.val.Department,
      Mark:location.state.val.Mark,


    })
  },[])
}
  return (
    <div>
      <h1>Add</h1>
      <TextField label="Name" variant="outlined"
        name='Name' value={student.Name} onChange={HandleInput} />
      <br /><br />
      <TextField label="Age" variant="outlined"
        name='Age' value={student.Age} onChange={HandleInput} />
      <br /><br />
      <TextField label="Department" variant="outlined"
        name='Department' value={student.Department} onChange={HandleInput} />
      <br /><br />
      <TextField label="Mark" variant="outlined"
        name='Mark' value={student.Mark} onChange={HandleInput} />
      <br /><br />
      <Button variant='contained' onClick={submitHandler}>add</Button>
    </div>
  )
}
export default Add